# Suleman Shahzad Graphic Designer Portfolio

Updated details:
- WhatsApp: 03330616587
- Email: sulemanshahzad122@gmail.com
- Instagram: removed

The website now opens with a login-style screen. Google, Facebook, and Email/Phone options are included as a front-end demo. Real Google/Facebook authentication requires OAuth credentials and a backend.

Open `index.html` in a browser to preview the site.
